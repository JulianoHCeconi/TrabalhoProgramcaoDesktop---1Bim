
package com.mycompany.trabalho1bim;

public class Trabalho1Bim {

    public static void main(String[] args) {
        new LoginFrame().setVisible(true);
    }
}
